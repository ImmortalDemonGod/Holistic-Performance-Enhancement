# jarc_reactor/config.py
# Configuration and parameters for the transformer model
# Precision setting for PyTorch Lightning Trainer
# Add near the top of config.py, after imports
import os
import torch
import logging

logger = logging.getLogger(__name__)

# Setup CUDA optimizations globally
def setup_cuda_optimizations():
    if torch.cuda.is_available():
        if torch.cuda.get_device_properties(0).major >= 7:  # Volta or newer
            # Enable Tensor Core operations for faster performance
            torch.set_float32_matmul_precision('medium')
            logger.info("Enabled Tensor Core optimizations for faster matrix operations")
            
            # Optional: Additional CUDA optimizations
            torch.backends.cuda.matmul.allow_tf32 = True  # Enable TF32 for faster training
            torch.backends.cudnn.benchmark = True  # Enable cudnn autotuner
            logger.info("Enabled additional CUDA optimizations")

# Call this early in initialization
setup_cuda_optimizations()

# Rest of your config.py code...
class ModelConfig:
    def __init__(self, input_dim, seq_len, d_model, encoder_layers, decoder_layers, heads, d_ff, output_dim, dropout_rate, context_encoder_d_model, context_encoder_heads, context_dropout_rate, encoder_dropout_rate, decoder_dropout_rate, lora_rank, use_lora, checkpoint_path):
        self.input_dim = input_dim
        self.seq_len = seq_len
        self.d_model = d_model
        self.encoder_layers = encoder_layers
        self.decoder_layers = decoder_layers
        self.heads = heads
        self.d_ff = d_ff
        self.output_dim = output_dim
        self.dropout = dropout_rate
        self.context_encoder_d_model = context_encoder_d_model
        self.context_dropout_rate = context_dropout_rate
        self.encoder_dropout_rate = encoder_dropout_rate
        self.decoder_dropout_rate = decoder_dropout_rate
        self.context_encoder_heads = context_encoder_heads
        self.lora_in_features = 128  # Example value; set appropriately
        self.lora_out_features = 128  # Example value; set appropriately
        self.lora_rank = lora_rank  # Rank for Low-Rank Adaptation
        self.use_lora = use_lora  # Ensure use_lora is initialized
        self.checkpoint_path = checkpoint_path  # New field for checkpoint path

class TrainingConfig:
    def __init__(self, batch_size, learning_rate, include_synthetic_training_data, num_epochs, device_choice='cpu', precision=None, fast_dev_run=None, train_from_checkpoint=None):
        if precision is None:
            precision = 32  # Default precision
        if fast_dev_run is None:
            fast_dev_run = True  # Default fast_dev_run
        if train_from_checkpoint is None:
            train_from_checkpoint = False  # Default train_from_checkpoint
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.max_epochs = num_epochs
        self.device_choice = device_choice
        self.precision = precision  # Moved here
        self.train_from_checkpoint = train_from_checkpoint
        self.include_synthetic_training_data = include_synthetic_training_data
        assert self.device_choice in ['cpu', 'gpu'], "device_choice must be 'cpu' or 'gpu'"
        assert self.precision in [16, 32, 64, 'bf16'], "Invalid precision value"
        self.gradient_clip_val = 1.0
        self.FAST_DEV_RUN = fast_dev_run
        self.training_data_dir = 'jarc_reactor/data/training_data/training'
# Options:
# - 16: Mixed precision (FP16) for reduced memory usage and faster training on supported GPUs
# - 32: Full precision (FP32), the default for most training scenarios
# - 64: Double precision (FP64), rarely used due to high computational cost
# - 'bf16': Bfloat16 precision, used for specific hardware that supports it
import torch
import logging

precision = 32  # Set to 16 for mixed precision, 32 for full precision, etc.
TRAIN_FROM_CHECKPOINT = False  # Set to True to resume training from a checkpoint
# These parameters should be treated as modifiable from the main run_model.py script

lora_rank = 128  # Commonly used values: 1, 2, 4, 8, 16
# Explanation:
# - The `lora_rank` parameter determines the rank of the low-rank matrices used in LoRA.
# - Commonly used values are typically small integers like 1, 2, 4, 8, or 16.
# - A lower rank (e.g., 1 or 2) means fewer parameters are added, which can lead to faster training and less memory usage.
# - A higher rank (e.g., 8 or 16) allows for more expressive power, potentially capturing more complex task-specific adaptations.
# - The choice of rank depends on the trade-off between computational efficiency and the complexity of the task.
# - In practice, a rank of 4 or 8 is often used as a balance between efficiency and performance.
use_lora = False
device_choice = 'gpu' if torch.cuda.is_available() else 'cpu'  # Auto-select device
calculate_parameters = True  # Whether to calculate and print the total parameter size before training
run_for_100_epochs = True  # Whether to only run for 100 epochs and estimate time for 20,000 epochs
num_epochs = 100  # Number of training epochs
seq_len = 30  # Sequence length
input_dim = 30  # Number of features per input row
d_model = 256  # Transformer model dimension
encoder_layers = 2  # Number of encoder layers
decoder_layers = 2   # Number of decoder layers
heads = 4  # Reduced number of attention heads for efficiency
d_ff = 128  # Feedforward network dimension
output_dim = 30  # Number of features per output row
learning_rate = 0.00002009  # Learning rate
batch_size = 1  # Batch size for DataLoader
dropout_rate = 0.15  # Dropout rate for the model
synthetic_dir = 'sythtraining'
include_synthetic_training_data = False  # Set to True to include synthetic data

#CHECKPOINT_PATH = "/kaggle/input/arc_checkpoint_test/pytorch/default/1/epoch3-step1748.ckpt"
CHECKPOINT_PATH = "/workspaces/JARC-Reactor/lightning_logs/checkpoints/model-step=step=40-val_loss=val_loss=1.7084.ckpt"

checkpoint_path = CHECKPOINT_PATH  # Ensure this is defined before use

FAST_DEV_RUN = False  # Set to True to enable fast development run

# Context Encoder Configuration
context_encoder_d_model = 1024  # Transformer model dimension for Context Encoder
context_encoder_heads = 16       # Number of attention heads for Context Encoder
# Fine-Tuning Configurations
finetuning_patience = 5
finetuning_max_epochs = 100

class OptunaConfig:
    def __init__(self):
        print("DEBUG: Creating OptunaConfig")
        
        self.n_trials = 1
        self.study_name = "jarc_optimization_v3"  # Updated study name
        self.storage_url = "sqlite:///jarc_optuna.db"
        
        # Expanded hyperparameter ranges
        self.param_ranges = {
            # Model Architecture
            # Model Architecture Parameters
            "d_model": (32, 2048, 16),      # Expanded from 32 to 512 with step 16
            "heads": [2, 4, 8, 16, 32, 64],    # Fixed list of choices
            "encoder_layers": (1, 12),     # Expanded upper bound to 12 layers
            "decoder_layers": (1, 12),     # Expanded upper bound to 12 layers
            "d_ff": (64, 2048, 64),        # Expanded from 64 to 1024 with step 64
            "dropout": (0.01, 0.7),        # Expanded dropout rate range
            
            # Context Encoder Parameters (actually used in model)
            "context_encoder_d_model": (32, 512, 32),  # Expanded from 32 to 512 with step 32
            "context_encoder_heads": [2, 4, 8],   # Fixed list of choices
            
            # Training Parameters
            "batch_size": (8, 512),                   # Expanded batch size range from 8 to 256
            "learning_rate": (1e-6, 1e-1),            # Expanded learning rate range from 1e-6 to 1e-1
            
            # **New:** Add max_epochs range
            "max_epochs": (4, 5, 1),       # Updated range
            "gradient_clip_val": (0.0, 5.0),  # Add gradient_clip_val range
        }
        
        # Pruning Configuration
        self.pruning = {
            "n_warmup_steps": 5,           # Number of trials before pruning starts
            "n_startup_trials": 10,        # Number of trials before using pruning
            "patience": 20,                 # Number of epochs without improvement before pruning
            "pruning_percentile": 25,      # Percentile for pruning
        }
        
        print("DEBUG: OptunaConfig created with ranges:", self.param_ranges)

class LoggingConfig:
    def __init__(self):
        self.level = "INFO"  # Default logging level
        self.debug_mode = False
        self.log_dir = "jarc_reactor/logs"  # New field for log directory
        logging.debug("Initializing LoggingConfig")  # Debugging statement

class FineTuningConfig:
    def __init__(self):
        self.mode = "all"  # "all" or "random"
        self.num_random_tasks = 1
        self.save_dir = "finetuning_results"
        self.max_epochs = 100
        self.learning_rate = 1e-5
        self.patience = 5


class SchedulerConfig:
    def __init__(self):
        self.use_cosine_annealing = True  # Set to True to enable CosineAnnealingWarmRestarts
        self.T_0 = 4  # Number of epochs for the first restart
        self.T_mult = 2  # Multiplicative factor to increase T_0 after each restart
        self.eta_min = 4e-7  # Minimum learning rate during annealing
class Config:
    def __init__(self, model=None, training=None, device_choice=None):
        context_dropout_rate = 0.12  # Example value for context encoder dropout
        encoder_dropout_rate = 0.61  # Example value for encoder dropout
        decoder_dropout_rate = 0.12  # Example value for decoder dropout

        # Initialize model attribute
        self.model = model if model is not None else ModelConfig(
            input_dim=input_dim,
            seq_len=seq_len,
            d_model=d_model,
            encoder_layers=encoder_layers,
            decoder_layers=decoder_layers,
            heads=heads,
            d_ff=d_ff,
            output_dim=output_dim,
            dropout_rate=dropout_rate,
            context_encoder_d_model=context_encoder_d_model,
            context_encoder_heads=context_encoder_heads,
            context_dropout_rate=context_dropout_rate,
            encoder_dropout_rate=encoder_dropout_rate,
            decoder_dropout_rate=decoder_dropout_rate,
            lora_rank=lora_rank,
            use_lora=use_lora,
            checkpoint_path=CHECKPOINT_PATH
        )
        
        # Set checkpoint_path after initializing the model
        self.model.checkpoint_path = CHECKPOINT_PATH
        
        # Determine device choice
        if device_choice is None:
            device_choice = 'gpu' if torch.cuda.is_available() else 'cpu'
        
        # Initialize training attribute
        self.training = training if training is not None else TrainingConfig(
            batch_size=batch_size,
            learning_rate=learning_rate,
            include_synthetic_training_data=include_synthetic_training_data,
            num_epochs=num_epochs,
            device_choice=device_choice,
            precision=precision,
            fast_dev_run=FAST_DEV_RUN,
            train_from_checkpoint=TRAIN_FROM_CHECKPOINT
        )
        
        self.logging = LoggingConfig()
        self.finetuning = FineTuningConfig()
        self.validate_config()
        self.optuna = OptunaConfig()
        # Initialize the evaluation configuration
        self.evaluation = EvaluationConfig()  # Add this line
        self.scheduler = SchedulerConfig()
        self.use_best_params = False

    def validate_config(self):
        """Validate configuration values"""
        assert self.training.batch_size > 0, "Batch size must be positive"
        assert self.training.learning_rate > 0, "Learning rate must be positive"
        assert self.training.device_choice in ['cpu', 'gpu'], "device_choice must be 'cpu' or 'gpu'"
        assert self.training.precision in [16, 32, 64, 'bf16'], "Invalid precision value"


class EvaluationConfig:
    def __init__(self):
        # Mode can be: 'training-validation', 'training-train', 'evaluation-only', 'all'
        self.mode = 'all'  
        self.output_dir = 'evaluation_results'
        self.debug_mode = True  # Enable extensive debugging
        self.save_predictions = True  # Save model predictions for analysis
        self.create_submission = True
        # Allow setting via environment variable, fallback to default path
        self.data_dir = os.getenv('EVALUATION_DATA_DIR', os.path.abspath(os.path.join('jarc_reactor', 'data', 'evaluation_data')))
        
        # Ensure the directory exists
        os.makedirs(self.data_dir, exist_ok=True)
        
        # Log the evaluation data directory path
        logger.debug(f"Evaluation data directory set to: {self.data_dir}")

# Instantiate the Config object so it can be accessed globally
config = Config()
